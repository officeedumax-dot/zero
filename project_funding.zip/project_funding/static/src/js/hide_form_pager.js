/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { FormRenderer } from "@web/views/form/form_renderer";

patch(FormRenderer.prototype, {
    /**
     * Ascunde complet record navigator (pager-ul) din dreapta sus
     */
    setup() {
        super.setup();

        // Elimină pager-ul (navigarea între înregistrări)
        if (this.props && this.props.pager) {
            this.props.pager = null;
        }
    }
});
