/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { ListRenderer } from "@web/views/list/list_renderer";
import { _t } from "@web/core/l10n/translation";

// Salvăm metoda originală
const originalOnDeleteRecord = ListRenderer.prototype.onDeleteRecord;

patch(ListRenderer.prototype, {
    /**
     * Suprascriem ștergerea în listă pentru modelul project.budget,
     * ca să cerem confirmare Da/Nu (folosind dialogul nativ al browserului).
     */
    async onDeleteRecord(record) {
        // Dacă nu e modelul nostru, apelăm metoda originală
        const resModel =
            (this.props && this.props.list && this.props.list.resModel) || null;
        if (resModel !== "project.budget") {
            if (originalOnDeleteRecord) {
                return originalOnDeleteRecord.apply(this, arguments);
            }
            return;
        }

        const message = _t("Confirmați ștergerea liniei de deviz?");
        const confirmed = window.confirm(message);

        if (!confirmed) {
            // utilizatorul a ales „Nu”/Cancel
            return;
        }

        // dacă a confirmat, apelăm metoda originală
        if (originalOnDeleteRecord) {
            return originalOnDeleteRecord.apply(this, arguments);
        }
    },
});
